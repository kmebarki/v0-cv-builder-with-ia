import * as React from "react"
export function Separator(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div role="separator" {...props} />
}
