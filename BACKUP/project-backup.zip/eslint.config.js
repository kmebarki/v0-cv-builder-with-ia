module.exports = [
  {
    ignores: ["node_modules", ".next", "dist", "coverage"],
  },
]
