export default function SettingsPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-4">Paramètres</h1>
      <p>Page de paramètres en cours de construction...</p>
    </div>
  )
}
